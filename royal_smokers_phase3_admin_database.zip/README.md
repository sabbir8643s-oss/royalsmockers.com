# Royal Smokers Phase 3

This phase adds a real local SQLite database and a session-protected admin panel.

Included:
- SQLite database created automatically
- bcrypt password hashing
- Express session login
- Helmet security headers
- Product CRUD from admin panel
- Inventory field
- Order management/status UI
- Public product API

Run:
1. Install Node.js 20+
2. `npm install`
3. Set production environment variables:
   - `SESSION_SECRET`
   - `ADMIN_EMAIL`
   - `ADMIN_PASSWORD`
4. `npm start`
5. Public site: `http://localhost:3000`
6. Admin: `http://localhost:3000/admin.html`

IMPORTANT:
- This is a development/production-foundation build, not a complete compliance-certified store.
- Before deployment, use HTTPS and a secure session store, rotate secrets, add CSRF protection, rate limiting, backups, logging and PostgreSQL for a multi-instance production deployment.
- Checkout/payment remains intentionally disabled.
- Do not use this system to bypass age, advertising, delivery, tax or payment-provider restrictions applicable to tobacco/vape products.
