import express from "express";
import session from "express-session";
import helmet from "helmet";
import bcrypt from "bcryptjs";
import Database from "better-sqlite3";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const db = new Database(path.join(__dirname, "royal-smokers.db"));
const PORT = process.env.PORT || 3000;

app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"1mb"}));
app.use(session({
  secret: process.env.SESSION_SECRET || "CHANGE_THIS_IN_PRODUCTION",
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:"lax",secure:false,maxAge:8*60*60*1000}
}));

db.exec(`
CREATE TABLE IF NOT EXISTS admins(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 email TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 category TEXT NOT NULL,
 price_cents INTEGER NOT NULL DEFAULT 0,
 stock INTEGER NOT NULL DEFAULT 0,
 active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders(
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_number TEXT UNIQUE NOT NULL,
 customer_name TEXT NOT NULL,
 customer_email TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending',
 total_cents INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

if (!db.prepare("SELECT id FROM admins LIMIT 1").get()) {
  const email = process.env.ADMIN_EMAIL || "admin@royalsmockers.com";
  const password = process.env.ADMIN_PASSWORD || "CHANGE-ME-NOW";
  db.prepare("INSERT INTO admins(email,password_hash) VALUES(?,?)")
    .run(email, bcrypt.hashSync(password, 12));
}

app.use(express.static(__dirname));

function adminOnly(req,res,next){
  if(!req.session.adminId) return res.status(401).json({error:"Admin login required"});
  next();
}

app.post("/api/admin/login",(req,res)=>{
  const {email,password}=req.body||{};
  const admin=db.prepare("SELECT * FROM admins WHERE email=?").get(email);
  if(!admin || !bcrypt.compareSync(password||"",admin.password_hash))
    return res.status(401).json({error:"Invalid email or password"});
  req.session.adminId=admin.id;
  res.json({ok:true,email:admin.email});
});

app.post("/api/admin/logout",(req,res)=>{
  req.session.destroy(()=>res.json({ok:true}));
});

app.get("/api/admin/me",adminOnly,(req,res)=>{
  const a=db.prepare("SELECT id,email FROM admins WHERE id=?").get(req.session.adminId);
  res.json(a);
});

app.get("/api/products",(req,res)=>{
  res.json(db.prepare("SELECT id,name,category,price_cents,stock,active FROM products WHERE active=1 ORDER BY id DESC").all());
});

app.get("/api/admin/products",adminOnly,(req,res)=>{
  res.json(db.prepare("SELECT * FROM products ORDER BY id DESC").all());
});

app.post("/api/admin/products",adminOnly,(req,res)=>{
  const {name,category,priceCents,stock,active=true}=req.body||{};
  if(!name||!category||!Number.isInteger(priceCents)||priceCents<0||!Number.isInteger(stock)||stock<0)
    return res.status(400).json({error:"Invalid product data"});
  const r=db.prepare("INSERT INTO products(name,category,price_cents,stock,active) VALUES(?,?,?,?,?)")
    .run(name,category,priceCents,stock,active?1:0);
  res.status(201).json({id:r.lastInsertRowid});
});

app.put("/api/admin/products/:id",adminOnly,(req,res)=>{
  const {name,category,priceCents,stock,active}=req.body||{};
  if(!name||!category||!Number.isInteger(priceCents)||priceCents<0||!Number.isInteger(stock)||stock<0)
    return res.status(400).json({error:"Invalid product data"});
  const r=db.prepare("UPDATE products SET name=?,category=?,price_cents=?,stock=?,active=?,updated_at=CURRENT_TIMESTAMP WHERE id=?")
    .run(name,category,priceCents,stock,active?1:0,req.params.id);
  if(!r.changes) return res.status(404).json({error:"Product not found"});
  res.json({ok:true});
});

app.delete("/api/admin/products/:id",adminOnly,(req,res)=>{
  db.prepare("DELETE FROM products WHERE id=?").run(req.params.id);
  res.json({ok:true});
});

app.get("/api/admin/orders",adminOnly,(req,res)=>{
  res.json(db.prepare("SELECT * FROM orders ORDER BY id DESC").all());
});

app.patch("/api/admin/orders/:id",adminOnly,(req,res)=>{
  const allowed=["pending","paid","processing","shipped","delivered","cancelled"];
  const {status}=req.body||{};
  if(!allowed.includes(status)) return res.status(400).json({error:"Invalid status"});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(status,req.params.id);
  res.json({ok:true});
});

app.listen(PORT,()=>console.log(`Royal Smokers Phase 3: http://localhost:${PORT}`));